package com.example.yogurtstudiomerch;
import java.util.HashMap;

public class Cart {
    public static HashMap<Integer,Integer> items = new HashMap<>();
    public static void add(int id){ items.put(id, items.containsKey(id) ? items.get(id)+1 : 1); }
    public static void plus(int id){ add(id); }
    public static void minus(int id){ if(!items.containsKey(id)) return; int q=items.get(id)-1; if(q<=0) items.remove(id); else items.put(id,q); }
    public static int count(){ int c=0; for(int q:items.values()) c+=q; return c; }
    public static void clear(){ items.clear(); }
}
