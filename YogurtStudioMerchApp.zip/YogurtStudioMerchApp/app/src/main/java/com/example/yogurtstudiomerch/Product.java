package com.example.yogurtstudiomerch;

public class Product {
    public int id, price, quantity, imageRes;
    public String name, category, description;
    public Product(int id, String name, String category, int price, int quantity, String description, int imageRes) {
        this.id=id; this.name=name; this.category=category; this.price=price; this.quantity=quantity; this.description=description; this.imageRes=imageRes;
    }
}
