package com.example.yogurtstudiomerch;
import android.app.*;import android.os.*;import android.database.*;import android.widget.*;import android.graphics.Color;

public class AdminActivity extends Activity{ DbHelper db; public void onCreate(Bundle b){ super.onCreate(b); db=new DbHelper(this); LinearLayout l=Ui.root(this); Ui.header(this,l,"Admin Panel"); l.addView(Ui.tv(this,"ADMIN\nТовары",24,1)); for(Product p:db.products(this)){ l.addView(Ui.tv(this,"ID: "+p.id+"\n"+p.name+" / "+p.category+"\nЦена: "+p.price+" ₽\nОстаток: "+p.quantity+"\n"+p.description,16,0)); } l.addView(Ui.tv(this,"Заказы",24,1)); Cursor c=db.orders(); if(c.getCount()==0) l.addView(Ui.tv(this,"Заказов пока нет",16,0)); while(c.moveToNext()){ l.addView(Ui.tv(this,"#"+c.getInt(0)+" | "+c.getString(1)+"\nТелефон: "+c.getString(2)+"\nАдрес: "+c.getString(3)+"\nСумма: "+c.getInt(4)+" ₽\nСтатус: "+c.getString(5)+"\nДата: "+c.getString(6),16,1)); } c.close(); }
}
