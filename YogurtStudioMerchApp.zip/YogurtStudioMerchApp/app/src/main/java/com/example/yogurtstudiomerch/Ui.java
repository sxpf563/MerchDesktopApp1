package com.example.yogurtstudiomerch;
import android.app.*;import android.content.*;import android.graphics.Color;import android.view.*;import android.widget.*;import android.text.InputType;

public class Ui {
    static TextView tv(Context c,String t,int sp,int style){ TextView v=new TextView(c); v.setText(t); v.setTextSize(sp); v.setTextColor(Color.rgb(17,17,17)); v.setTypeface(null,style); v.setPadding(18,10,18,10); return v; }
    static Button btn(Context c,String t){ Button b=new Button(c); b.setText(t); b.setTextColor(Color.WHITE); b.setBackgroundColor(Color.BLACK); return b; }
    static LinearLayout root(Activity a){ ScrollView s=new ScrollView(a); LinearLayout l=new LinearLayout(a); l.setOrientation(LinearLayout.VERTICAL); l.setPadding(24,24,24,24); s.addView(l); a.setContentView(s); return l; }
    static void header(Activity a, LinearLayout l, String title){ LinearLayout h=new LinearLayout(a); h.setOrientation(LinearLayout.VERTICAL); h.setBackgroundColor(Color.BLACK); h.setPadding(18,18,18,18); TextView logo=tv(a,title,24,1); logo.setTextColor(Color.WHITE); h.addView(logo); LinearLayout row=new LinearLayout(a); row.setOrientation(LinearLayout.HORIZONTAL); Button catalog=btn(a,"Каталог"); catalog.setOnClickListener(v->a.startActivity(new Intent(a,MainActivity.class))); Button cart=btn(a,"Корзина ("+Cart.count()+")"); cart.setOnClickListener(v->a.startActivity(new Intent(a,CartActivity.class))); Button admin=btn(a,"Админка"); admin.setOnClickListener(v->a.startActivity(new Intent(a,AdminActivity.class))); row.addView(catalog);row.addView(cart);row.addView(admin); h.addView(row); l.addView(h); }
    static EditText input(Context c,String hint,boolean multi){ EditText e=new EditText(c); e.setHint(hint); e.setSingleLine(!multi); if(multi) e.setMinLines(3); e.setInputType(InputType.TYPE_CLASS_TEXT|InputType.TYPE_TEXT_FLAG_CAP_SENTENCES); e.setPadding(14,14,14,14); return e; }
}
