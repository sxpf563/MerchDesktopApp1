package com.example.yogurtstudiomerch;

import android.content.*;import android.database.*;import android.database.sqlite.*;import java.util.*;

public class DbHelper extends SQLiteOpenHelper {
    private Context appContext;
    public DbHelper(Context c){ super(c,"merch_db",null,1); appContext=c.getApplicationContext(); }
    public void onCreate(SQLiteDatabase db){
        db.execSQL("CREATE TABLE products(id INTEGER PRIMARY KEY, name TEXT, category TEXT, price INTEGER, quantity INTEGER, description TEXT, image TEXT)");
        db.execSQL("CREATE TABLE orders(id INTEGER PRIMARY KEY AUTOINCREMENT, customer_name TEXT, phone TEXT, address TEXT, total INTEGER, status TEXT DEFAULT 'Новый', created_at TEXT DEFAULT CURRENT_TIMESTAMP)");
        db.execSQL("CREATE TABLE order_items(id INTEGER PRIMARY KEY AUTOINCREMENT, order_id INTEGER, product_id INTEGER, product_name TEXT, price INTEGER, quantity INTEGER)");
        db.execSQL("INSERT INTO products VALUES(1,'Футболка','Одежда',1200,15,'Белая футболка с надписью YogurtStudio','tshirt')");
        db.execSQL("INSERT INTO products VALUES(2,'Худи','Одежда',2500,8,'Белое худи с надписью YogurtStudio','hoodie')");
        db.execSQL("INSERT INTO products VALUES(3,'Кружка','Сувениры',600,19,'Белая кружка с логотипом YogurtStudio','mug')");
    }
    public void onUpgrade(SQLiteDatabase db,int oldV,int newV){ db.execSQL("DROP TABLE IF EXISTS order_items");db.execSQL("DROP TABLE IF EXISTS orders");db.execSQL("DROP TABLE IF EXISTS products");onCreate(db); }
    int imageRes(Context c,String name){ return c.getResources().getIdentifier(name,"drawable",c.getPackageName()); }
    public ArrayList<Product> products(){ ArrayList<Product> list=new ArrayList<>(); SQLiteDatabase db=getReadableDatabase(); Cursor r=db.rawQuery("SELECT * FROM products ORDER BY id",null); while(r.moveToNext()) list.add(new Product(r.getInt(0),r.getString(1),r.getString(2),r.getInt(3),r.getInt(4),r.getString(5),imageRes(appContext,r.getString(6)))); r.close(); return list; }
    public ArrayList<Product> products(Context c){ return products(); }
    public Product product(Context c,int id){ for(Product p:products()) if(p.id==id) return p; return null; }
    public int createOrder(String name,String phone,String address){
        SQLiteDatabase db=getWritableDatabase(); int total=0; for(Integer id:Cart.items.keySet()){ Product p=product(appContext,id); if(p!=null) total+=p.price*Cart.items.get(id); }
        ContentValues o=new ContentValues(); o.put("customer_name",name);o.put("phone",phone);o.put("address",address);o.put("total",total);o.put("status","Новый"); long orderId=db.insert("orders",null,o);
        for(Integer id:Cart.items.keySet()){ Product p=product(appContext,id); if(p==null) continue; int qty=Cart.items.get(id); ContentValues it=new ContentValues(); it.put("order_id",orderId);it.put("product_id",id);it.put("product_name",p.name);it.put("price",p.price);it.put("quantity",qty); db.insert("order_items",null,it); db.execSQL("UPDATE products SET quantity=quantity-? WHERE id=?",new Object[]{qty,id}); }
        return (int)orderId;
    }
    public Cursor orders(){ return getReadableDatabase().rawQuery("SELECT id,customer_name,phone,address,total,status,created_at FROM orders ORDER BY id DESC",null); }
}
